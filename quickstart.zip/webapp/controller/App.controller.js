sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
    "use strict";
    return Controller.extend("myApp.controller.App", {
      onInit: function () {
        // Controller logic here (optional for now)
      }
    });
  });
   