sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel"
  ], function (UIComponent, JSONModel) {
    "use strict";
  
    return UIComponent.extend("myApp.Component", {
      metadata: {
        manifest: "json"
      },
  
      init: function () {
        UIComponent.prototype.init.apply(this, arguments);
        
        // Mock model
        const oData = {
          students: 243,
          courses: 13,
          payments: 556000,
          users: 3
        };
  
        const oModel = new JSONModel(oData);
        this.setModel(oModel, "dashboard");
      }
    });
  });
  